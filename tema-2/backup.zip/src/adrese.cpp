#include <bits/stdc++.h>
using namespace std;

struct person {
    string name;
    vector<string> addresses;
};

class Adrese {
 public:
    void solve() {
        read_input();
        print_output(get_result());
    }

 private:
    static constexpr int NMAX = 1001;

    int n;
    unordered_map<string, vector<int>> address_ids;
    unordered_map<int, person> id_person;
    vector<int> adj[NMAX];

    void read_input() {
        ifstream fin("adrese.in");

        int id = 1;
        fin >> n;

        for (int i = 0; i < n; i++) {
            string name;
            int add_no;

            fin >> name >> add_no;

            person new_person;
            new_person.name = name;

            for (int j = 0; j < add_no; j++) {
                string address;
                fin >> address;

                new_person.addresses.push_back(address);
            }

            id_person.insert({ id, new_person });

            for (string a : new_person.addresses) {
                vector<int> ids;

                if (address_ids.find(a) != address_ids.end()) {
                    ids = address_ids.at(a);
                    address_ids.erase(a);
                }

                ids.push_back(id);
                address_ids.insert({ a, ids });
            }

            id++;
        }

        fin.close();
    }

    void build_adj_list() {
        for (auto a : address_ids) {
            for (int i = 0; i < a.second.size() - 1; i++) {
                for (int j = i + 1; j < a.second.size(); j++) {
                    adj[a.second[i]].push_back(a.second[j]);
                    adj[a.second[j]].push_back(a.second[i]);
                }
            }
        }
    }

    void dfs_recursive(int node, bool *visited, vector<person> &to_unify) {
        for (auto neigh : adj[node]) {
            if (visited[neigh] == false) {
                visited[neigh] = true;
                to_unify.push_back(id_person.at(neigh));

                dfs_recursive(neigh, visited, to_unify);
            }
        }
    }

    person unify(vector<person> to_unify) {
        person real_person;
        real_person.name = to_unify[0].name;

        for (int i = 0; i < to_unify.size(); i++) {
            for (auto address : to_unify[i].addresses) {
                real_person.addresses.push_back(address);
            }

            if (to_unify[i].name < real_person.name) {
                real_person.name = to_unify[i].name;
            }
        }

        sort(real_person.addresses.begin(), real_person.addresses.end());
        real_person.addresses.erase(unique(real_person.addresses.begin(),
            real_person.addresses.end()), real_person.addresses.end());

        return real_person;
    }

    vector<person> get_result() {
        build_adj_list();

        bool visited[NMAX] = {0};
        vector<person> real_persons;
        vector<person> to_unify;

        for (int node = 1; node <= n; node++) {
            if (visited[node] == false) {
                visited[node] = true;
                to_unify.push_back(id_person.at(node));

                dfs_recursive(node, visited, to_unify);

                real_persons.push_back(unify(to_unify));
                to_unify.clear();
            }
        }

        return real_persons;
    }

    void print_output(vector<person> real_persons) {
        ofstream fout("adrese.out");

        sort(real_persons.begin(), real_persons.end(),
            [](person p1, person p2) {
                if (p1.addresses.size() == p2.addresses.size()) {
                    return p1.name < p2.name;
                }
                return p1.addresses.size() < p2.addresses.size();
            });

        fout << real_persons.size() << endl;

        for (int i = 0; i < real_persons.size(); i++) {
            fout << real_persons[i].name << " " <<
                    real_persons[i].addresses.size() << endl;

            for (auto address : real_persons[i].addresses) {
                fout << address << endl;
            }
        }

        fout.close();
    }
};

int main() {
    auto* adrese = new (nothrow)Adrese();

    if (!adrese) {
        cerr << "new failed\n";
        return -1;
    }

    adrese->solve();
    delete adrese;
    return 0;
}
